import { Link, Outlet } from "react-router-dom";

export default function Navbar(){
    return (
    <>
        <div className="navbar">
            <div style={{fontWeight:'800', color:'white', fontSize:30, height:'fit-content'}}>RE<span style={{color:'black'}}>SEE</span>PE</div>
            <div className="urls">
                <div>
                    <Link to='home'>HOME</Link>
                    <Link to='recipes'>RECIPES</Link>
                    <Link to='category'>CATEGORY</Link>
                    <Link to='favorites'>FAVORITES</Link>
                </div>
            </div>
        </div>

        <Outlet />
    </>
    );
}